# Visualising MIDI with Python and Matplotlib
A fun little project to turn MIDI files into charts with `python-midi` and `matplotlib`.

To run the script:
- `pip install -r requirements.txt` (recommended to do this in a virtualenv)
- `python midivis.py [PATH TO MIDI FILE TO PLOT]`
